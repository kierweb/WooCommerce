Installation :
Unzip and upload the plugin folder to your /wp-content/plugins/ directory
Activate the plugin through the Plugins menu in WordPress
Go to WooCommerce -> Settings and click on the Checkout tab. Find Cardstream in the Payment Gateways section and click the settings button to configure and enable the gateway.
Click 'Save Changes'.